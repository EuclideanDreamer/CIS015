﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Clear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbCurrentSalary = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lbl5percent = New System.Windows.Forms.Label()
        Me.lbl8percent = New System.Windows.Forms.Label()
        Me.lbl8salary = New System.Windows.Forms.Label()
        Me.lbl5salary = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.Color.LimeGreen
        Me.btnCalculate.Location = New System.Drawing.Point(171, 367)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(125, 50)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.IndianRed
        Me.btnExit.Location = New System.Drawing.Point(618, 367)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(125, 50)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'Clear
        '
        Me.Clear.Location = New System.Drawing.Point(421, 367)
        Me.Clear.Name = "Clear"
        Me.Clear.Size = New System.Drawing.Size(125, 50)
        Me.Clear.TabIndex = 2
        Me.Clear.Text = "Clear"
        Me.Clear.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Current Salary"
        '
        'tbCurrentSalary
        '
        Me.tbCurrentSalary.Location = New System.Drawing.Point(27, 40)
        Me.tbCurrentSalary.Name = "tbCurrentSalary"
        Me.tbCurrentSalary.Size = New System.Drawing.Size(216, 27)
        Me.tbCurrentSalary.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(92, 148)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "5% Raise"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(92, 215)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "8% Raise"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(115, 113)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Raise"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(343, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "New Salary"
        '
        'lbl5percent
        '
        Me.lbl5percent.AutoSize = True
        Me.lbl5percent.Location = New System.Drawing.Point(115, 184)
        Me.lbl5percent.Name = "lbl5percent"
        Me.lbl5percent.Size = New System.Drawing.Size(53, 20)
        Me.lbl5percent.TabIndex = 9
        Me.lbl5percent.Text = "Label6"
        '
        'lbl8percent
        '
        Me.lbl8percent.AutoSize = True
        Me.lbl8percent.Location = New System.Drawing.Point(115, 252)
        Me.lbl8percent.Name = "lbl8percent"
        Me.lbl8percent.Size = New System.Drawing.Size(53, 20)
        Me.lbl8percent.TabIndex = 10
        Me.lbl8percent.Text = "Label7"
        '
        'lbl8salary
        '
        Me.lbl8salary.AutoSize = True
        Me.lbl8salary.Location = New System.Drawing.Point(373, 252)
        Me.lbl8salary.Name = "lbl8salary"
        Me.lbl8salary.Size = New System.Drawing.Size(53, 20)
        Me.lbl8salary.TabIndex = 11
        Me.lbl8salary.Text = "Label8"
        '
        'lbl5salary
        '
        Me.lbl5salary.AutoSize = True
        Me.lbl5salary.Location = New System.Drawing.Point(373, 184)
        Me.lbl5salary.Name = "lbl5salary"
        Me.lbl5salary.Size = New System.Drawing.Size(53, 20)
        Me.lbl5salary.TabIndex = 12
        Me.lbl5salary.Text = "Label9"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lbl5salary)
        Me.Controls.Add(Me.lbl8salary)
        Me.Controls.Add(Me.lbl8percent)
        Me.Controls.Add(Me.lbl5percent)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tbCurrentSalary)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Clear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "MainForm"
        Me.Text = "Salary Project"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Clear As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents tbCurrentSalary As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lbl5percent As Label
    Friend WithEvents lbl8percent As Label
    Friend WithEvents lbl8salary As Label
    Friend WithEvents lbl5salary As Label
End Class
