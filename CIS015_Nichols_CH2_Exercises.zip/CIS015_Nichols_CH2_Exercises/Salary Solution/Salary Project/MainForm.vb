﻿Public Class MainForm
    'Name: Salary Project
    'Purpose: take a number from a user and use that as a current salary to display the results of a potenta 5 or8 percent raise
    'Programmer: Bailey Nichols 02/22/2022

    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click

        'clear all fieds

        lbl5percent.Text = " "
        lbl8percent.Text = " "
        lbl5salary.Text = " "
        lbl8salary.Text = " "
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'constants
        Const EightPercent As Decimal = 0.08
        Const FivePercent As Decimal = 0.05

        'vars 
        Dim decCurrentSalary As Decimal = tbCurrentSalary.Text

        Dim decEightPercentRaise As Decimal = EightPercent * decCurrentSalary
        Dim decFivetPercentRaise As Decimal = FivePercent * decCurrentSalary

        Dim decEightPercentSalary As Decimal = decCurrentSalary + decEightPercentRaise
        Dim decFivePercentSalary As Decimal = decCurrentSalary + decFivetPercentRaise

        'now display
        lbl5percent.Text = decFivetPercentRaise
        lbl8percent.Text = decEightPercentRaise
        lbl5salary.Text = decFivePercentSalary
        lbl8salary.Text = decEightPercentSalary

    End Sub
End Class
