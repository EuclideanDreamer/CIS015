﻿Public Class Moonbucks
    'Name: Moonbucks 
    'Purpose: to exit the porgram, and fufill reqirements of specifications. 
    'Programmer: Bailey Nichols 2/22/2022
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub
End Class
