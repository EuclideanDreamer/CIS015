﻿' Name:         Amlie Project
' Purpose:      Display a gift certificate.
' Programmer:   Bailey Nichols on 02/22/2022

Public Class frmMain
    Dim strTxtDate As String
    Dim strTxtAmnt As String
    Dim strTxtName As String


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        strTxtDate = txtDate.Text
        strTxtAmnt = txtAmount.Text
        strTxtName = txtRecipient.Text
        MessageBox.Show(strTxtName + " " + strTxtDate + " " + strTxtAmnt)
    End Sub
End Class
