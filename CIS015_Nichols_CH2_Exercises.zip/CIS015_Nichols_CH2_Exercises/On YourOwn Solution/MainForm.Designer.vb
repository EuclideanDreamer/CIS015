﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DegreeLabel = New System.Windows.Forms.Label()
        Me.degSinLabel = New System.Windows.Forms.Label()
        Me.degCosLabel = New System.Windows.Forms.Label()
        Me.degTanLabel = New System.Windows.Forms.Label()
        Me.radTanLabel = New System.Windows.Forms.Label()
        Me.radCosLabel = New System.Windows.Forms.Label()
        Me.radSinLabel = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.DegreeTB = New System.Windows.Forms.TextBox()
        Me.RadianTB = New System.Windows.Forms.TextBox()
        Me.Calculate = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.degToRadLabel = New System.Windows.Forms.Label()
        Me.radToDegree = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'DegreeLabel
        '
        Me.DegreeLabel.AutoSize = True
        Me.DegreeLabel.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.DegreeLabel.Location = New System.Drawing.Point(55, 22)
        Me.DegreeLabel.Name = "DegreeLabel"
        Me.DegreeLabel.Size = New System.Drawing.Size(114, 37)
        Me.DegreeLabel.TabIndex = 0
        Me.DegreeLabel.Text = "Degrees"
        '
        'degSinLabel
        '
        Me.degSinLabel.AutoSize = True
        Me.degSinLabel.Location = New System.Drawing.Point(55, 142)
        Me.degSinLabel.Name = "degSinLabel"
        Me.degSinLabel.Size = New System.Drawing.Size(13, 20)
        Me.degSinLabel.TabIndex = 1
        Me.degSinLabel.Text = " "
        '
        'degCosLabel
        '
        Me.degCosLabel.AutoSize = True
        Me.degCosLabel.Location = New System.Drawing.Point(55, 186)
        Me.degCosLabel.Name = "degCosLabel"
        Me.degCosLabel.Size = New System.Drawing.Size(13, 20)
        Me.degCosLabel.TabIndex = 2
        Me.degCosLabel.Text = " "
        '
        'degTanLabel
        '
        Me.degTanLabel.AutoSize = True
        Me.degTanLabel.Location = New System.Drawing.Point(55, 231)
        Me.degTanLabel.Name = "degTanLabel"
        Me.degTanLabel.Size = New System.Drawing.Size(13, 20)
        Me.degTanLabel.TabIndex = 3
        Me.degTanLabel.Text = " "
        '
        'radTanLabel
        '
        Me.radTanLabel.AutoSize = True
        Me.radTanLabel.Location = New System.Drawing.Point(280, 231)
        Me.radTanLabel.Name = "radTanLabel"
        Me.radTanLabel.Size = New System.Drawing.Size(13, 20)
        Me.radTanLabel.TabIndex = 7
        Me.radTanLabel.Text = " "
        '
        'radCosLabel
        '
        Me.radCosLabel.AutoSize = True
        Me.radCosLabel.Location = New System.Drawing.Point(280, 186)
        Me.radCosLabel.Name = "radCosLabel"
        Me.radCosLabel.Size = New System.Drawing.Size(13, 20)
        Me.radCosLabel.TabIndex = 6
        Me.radCosLabel.Text = " "
        '
        'radSinLabel
        '
        Me.radSinLabel.AutoSize = True
        Me.radSinLabel.Location = New System.Drawing.Point(280, 142)
        Me.radSinLabel.Name = "radSinLabel"
        Me.radSinLabel.Size = New System.Drawing.Size(13, 20)
        Me.radSinLabel.TabIndex = 5
        Me.radSinLabel.Text = " "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(280, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(110, 37)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Radians"
        '
        'DegreeTB
        '
        Me.DegreeTB.Location = New System.Drawing.Point(55, 57)
        Me.DegreeTB.Name = "DegreeTB"
        Me.DegreeTB.Size = New System.Drawing.Size(111, 27)
        Me.DegreeTB.TabIndex = 8
        '
        'RadianTB
        '
        Me.RadianTB.Location = New System.Drawing.Point(280, 57)
        Me.RadianTB.Name = "RadianTB"
        Me.RadianTB.Size = New System.Drawing.Size(111, 27)
        Me.RadianTB.TabIndex = 9
        '
        'Calculate
        '
        Me.Calculate.Location = New System.Drawing.Point(55, 266)
        Me.Calculate.Name = "Calculate"
        Me.Calculate.Size = New System.Drawing.Size(114, 61)
        Me.Calculate.TabIndex = 10
        Me.Calculate.Text = "Calculate Degree"
        Me.Calculate.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(182, 266)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(111, 61)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Calculate Radian"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'degToRadLabel
        '
        Me.degToRadLabel.AutoSize = True
        Me.degToRadLabel.Location = New System.Drawing.Point(55, 99)
        Me.degToRadLabel.Name = "degToRadLabel"
        Me.degToRadLabel.Size = New System.Drawing.Size(13, 20)
        Me.degToRadLabel.TabIndex = 12
        Me.degToRadLabel.Text = " "
        '
        'radToDegree
        '
        Me.radToDegree.AutoSize = True
        Me.radToDegree.Location = New System.Drawing.Point(280, 99)
        Me.radToDegree.Name = "radToDegree"
        Me.radToDegree.Size = New System.Drawing.Size(13, 20)
        Me.radToDegree.TabIndex = 13
        Me.radToDegree.Text = " "
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(433, 266)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(111, 44)
        Me.btnClear.TabIndex = 14
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(658, 266)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(111, 44)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 474)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.radToDegree)
        Me.Controls.Add(Me.degToRadLabel)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Calculate)
        Me.Controls.Add(Me.RadianTB)
        Me.Controls.Add(Me.DegreeTB)
        Me.Controls.Add(Me.radTanLabel)
        Me.Controls.Add(Me.radCosLabel)
        Me.Controls.Add(Me.radSinLabel)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.degTanLabel)
        Me.Controls.Add(Me.degCosLabel)
        Me.Controls.Add(Me.degSinLabel)
        Me.Controls.Add(Me.DegreeLabel)
        Me.Name = "Form1"
        Me.Text = "Trigonometry Helper"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DegreeLabel As Label
    Friend WithEvents degSinLabel As Label
    Friend WithEvents degCosLabel As Label
    Friend WithEvents degTanLabel As Label
    Friend WithEvents radTanLabel As Label
    Friend WithEvents radCosLabel As Label
    Friend WithEvents radSinLabel As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents DegreeTB As TextBox
    Friend WithEvents RadianTB As TextBox
    Friend WithEvents Calculate As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents degToRadLabel As Label
    Friend WithEvents radToDegree As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
