﻿Public Class MainForm
    'Name: Trig Helper
    'Purpose: To help with trig by giving the sine, cosine and tangent of a degree or radian number
    'Programmer: Bailey Nichols 02/20/2022

    Private Sub Calculate_Click(sender As Object, e As EventArgs) Handles Calculate.Click
        Dim degreeNum As Double

        Dim pi = 3.14159R

        'math on degree side
        degreeNum = Convert.ToDouble(DegreeTB.Text)

        Dim radsFromDeg = degreeNum * (pi / 180)

        Dim sinFromDegree = Math.Sin(radsFromDeg)

        Dim cosFromDegree = Math.Cos(radsFromDeg)

        Dim tanFromDegree = Math.Tan(radsFromDeg)


        'puting degree side 

        degSinLabel.Text = "Sine: " + Convert.ToString(sinFromDegree)

        degCosLabel.Text = "Cosine: " + Convert.ToString(cosFromDegree)

        degTanLabel.Text = "Tangent: " + Convert.ToString(tanFromDegree)

        degToRadLabel.Text = "Radians: " + Convert.ToString(radsFromDeg)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'printing radian side
        Dim pi = 3.14159R
        'math on radian side
        Dim radianNum = Convert.ToDouble(RadianTB.Text)

        Dim sinFromRads = Math.Sin(radianNum)

        Dim cosFromRads = Math.Cos(radianNum)

        Dim tanFromRads = Math.Tan(radianNum)

        Dim degreeFromRad = radianNum * (180 / pi)

        radSinLabel.Text = "Sine: " + Convert.ToString(sinFromRads)

        radCosLabel.Text = "Cosine: " + Convert.ToString(cosFromRads)

        radTanLabel.Text = "Tangent: " + Convert.ToString(tanFromRads)

        radToDegree.Text = "Degrees: " + Convert.ToString(degreeFromRad)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'end operation
        End
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clear all labels
        radSinLabel.Text = " "

        radCosLabel.Text = " "

        radTanLabel.Text = " "

        radToDegree.Text = " "

        degSinLabel.Text = " "

        degCosLabel.Text = " "

        degTanLabel.Text = " "

        degToRadLabel.Text = " "
    End Sub
End Class
