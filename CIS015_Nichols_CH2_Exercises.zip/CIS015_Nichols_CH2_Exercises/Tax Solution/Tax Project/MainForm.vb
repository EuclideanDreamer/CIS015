﻿Public Class MainForm
    'Name: Tax Project
    'Purpose: to show the amount of proprety tax for a given proprety value
    'Programmer: Bailey Nichols 02/22/2022

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        End

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'variables
        Const decTax As Decimal = 1.35D
        Dim decValue As Decimal
        Dim decResult As Decimal
        'get number
        decValue = tbValueInput.Text
        'get & display result
        decResult = decTax * decValue
        lblTaxAmountDisplay.Text = decResult





    End Sub
End Class
