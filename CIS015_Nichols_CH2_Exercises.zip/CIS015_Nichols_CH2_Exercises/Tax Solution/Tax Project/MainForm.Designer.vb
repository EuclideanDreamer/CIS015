﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblTxAmount = New System.Windows.Forms.Label()
        Me.lblPropretyValue = New System.Windows.Forms.Label()
        Me.lblTaxAmountDisplay = New System.Windows.Forms.Label()
        Me.tbValueInput = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(605, 386)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(100, 36)
        Me.cmdExit.TabIndex = 0
        Me.cmdExit.Text = "&Exit"
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(357, 386)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(130, 36)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Calculate"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblTxAmount
        '
        Me.lblTxAmount.AutoSize = True
        Me.lblTxAmount.Location = New System.Drawing.Point(575, 172)
        Me.lblTxAmount.Name = "lblTxAmount"
        Me.lblTxAmount.Size = New System.Drawing.Size(79, 20)
        Me.lblTxAmount.TabIndex = 2
        Me.lblTxAmount.Text = "Tax Amont"
        '
        'lblPropretyValue
        '
        Me.lblPropretyValue.AutoSize = True
        Me.lblPropretyValue.Location = New System.Drawing.Point(357, 172)
        Me.lblPropretyValue.Name = "lblPropretyValue"
        Me.lblPropretyValue.Size = New System.Drawing.Size(105, 20)
        Me.lblPropretyValue.TabIndex = 3
        Me.lblPropretyValue.Text = "Proprety Value"
        '
        'lblTaxAmountDisplay
        '
        Me.lblTaxAmountDisplay.AutoSize = True
        Me.lblTaxAmountDisplay.Location = New System.Drawing.Point(575, 215)
        Me.lblTaxAmountDisplay.Name = "lblTaxAmountDisplay"
        Me.lblTaxAmountDisplay.Size = New System.Drawing.Size(53, 20)
        Me.lblTaxAmountDisplay.TabIndex = 4
        Me.lblTaxAmountDisplay.Text = "Label3"
        '
        'tbValueInput
        '
        Me.tbValueInput.Location = New System.Drawing.Point(345, 212)
        Me.tbValueInput.Name = "tbValueInput"
        Me.tbValueInput.Size = New System.Drawing.Size(224, 27)
        Me.tbValueInput.TabIndex = 5
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.tbValueInput)
        Me.Controls.Add(Me.lblTaxAmountDisplay)
        Me.Controls.Add(Me.lblPropretyValue)
        Me.Controls.Add(Me.lblTxAmount)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.cmdExit)
        Me.Name = "MainForm"
        Me.Text = "Tax Project"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdExit As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents lblTxAmount As Label
    Friend WithEvents lblPropretyValue As Label
    Friend WithEvents lblTaxAmountDisplay As Label
    Friend WithEvents tbValueInput As TextBox
End Class
