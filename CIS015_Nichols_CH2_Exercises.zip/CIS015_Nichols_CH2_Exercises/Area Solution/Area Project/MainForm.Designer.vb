﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblArea = New System.Windows.Forms.Label()
        Me.lblParameter = New System.Windows.Forms.Label()
        Me.lblParameterDisplayFeet = New System.Windows.Forms.Label()
        Me.lblAreaDisplayFeet = New System.Windows.Forms.Label()
        Me.lblLength = New System.Windows.Forms.Label()
        Me.lblHeight = New System.Windows.Forms.Label()
        Me.tbHeight = New System.Windows.Forms.TextBox()
        Me.tbLength = New System.Windows.Forms.TextBox()
        Me.lblFeet = New System.Windows.Forms.Label()
        Me.lblYd = New System.Windows.Forms.Label()
        Me.lblDisplayParameterYd = New System.Windows.Forms.Label()
        Me.lblAreaDisplayYd = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(375, 365)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(124, 47)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(620, 365)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(124, 47)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Location = New System.Drawing.Point(530, 97)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(40, 20)
        Me.lblArea.TabIndex = 2
        Me.lblArea.Text = "Area"
        '
        'lblParameter
        '
        Me.lblParameter.AutoSize = True
        Me.lblParameter.Location = New System.Drawing.Point(530, 148)
        Me.lblParameter.Name = "lblParameter"
        Me.lblParameter.Size = New System.Drawing.Size(76, 20)
        Me.lblParameter.TabIndex = 3
        Me.lblParameter.Text = "Parameter"
        '
        'lblParameterDisplayFeet
        '
        Me.lblParameterDisplayFeet.AutoSize = True
        Me.lblParameterDisplayFeet.Location = New System.Drawing.Point(530, 168)
        Me.lblParameterDisplayFeet.Name = "lblParameterDisplayFeet"
        Me.lblParameterDisplayFeet.Size = New System.Drawing.Size(0, 20)
        Me.lblParameterDisplayFeet.TabIndex = 5
        '
        'lblAreaDisplayFeet
        '
        Me.lblAreaDisplayFeet.AutoSize = True
        Me.lblAreaDisplayFeet.Location = New System.Drawing.Point(530, 117)
        Me.lblAreaDisplayFeet.Name = "lblAreaDisplayFeet"
        Me.lblAreaDisplayFeet.Size = New System.Drawing.Size(0, 20)
        Me.lblAreaDisplayFeet.TabIndex = 4
        '
        'lblLength
        '
        Me.lblLength.AutoSize = True
        Me.lblLength.Location = New System.Drawing.Point(240, 137)
        Me.lblLength.Name = "lblLength"
        Me.lblLength.Size = New System.Drawing.Size(54, 20)
        Me.lblLength.TabIndex = 7
        Me.lblLength.Text = "Length"
        '
        'lblHeight
        '
        Me.lblHeight.AutoSize = True
        Me.lblHeight.Location = New System.Drawing.Point(79, 137)
        Me.lblHeight.Name = "lblHeight"
        Me.lblHeight.Size = New System.Drawing.Size(54, 20)
        Me.lblHeight.TabIndex = 6
        Me.lblHeight.Text = "Height"
        '
        'tbHeight
        '
        Me.tbHeight.Location = New System.Drawing.Point(79, 161)
        Me.tbHeight.Name = "tbHeight"
        Me.tbHeight.Size = New System.Drawing.Size(125, 27)
        Me.tbHeight.TabIndex = 8
        '
        'tbLength
        '
        Me.tbLength.Location = New System.Drawing.Point(240, 161)
        Me.tbLength.Name = "tbLength"
        Me.tbLength.Size = New System.Drawing.Size(125, 27)
        Me.tbLength.TabIndex = 9
        '
        'lblFeet
        '
        Me.lblFeet.AutoSize = True
        Me.lblFeet.Location = New System.Drawing.Point(620, 80)
        Me.lblFeet.Name = "lblFeet"
        Me.lblFeet.Size = New System.Drawing.Size(37, 20)
        Me.lblFeet.TabIndex = 10
        Me.lblFeet.Text = "Feet"
        '
        'lblYd
        '
        Me.lblYd.AutoSize = True
        Me.lblYd.Location = New System.Drawing.Point(620, 206)
        Me.lblYd.Name = "lblYd"
        Me.lblYd.Size = New System.Drawing.Size(44, 20)
        Me.lblYd.TabIndex = 15
        Me.lblYd.Text = "Yards"
        '
        'lblDisplayParameterYd
        '
        Me.lblDisplayParameterYd.AutoSize = True
        Me.lblDisplayParameterYd.Location = New System.Drawing.Point(530, 292)
        Me.lblDisplayParameterYd.Name = "lblDisplayParameterYd"
        Me.lblDisplayParameterYd.Size = New System.Drawing.Size(0, 20)
        Me.lblDisplayParameterYd.TabIndex = 14
        '
        'lblAreaDisplayYd
        '
        Me.lblAreaDisplayYd.AutoSize = True
        Me.lblAreaDisplayYd.Location = New System.Drawing.Point(530, 238)
        Me.lblAreaDisplayYd.Name = "lblAreaDisplayYd"
        Me.lblAreaDisplayYd.Size = New System.Drawing.Size(0, 20)
        Me.lblAreaDisplayYd.TabIndex = 13
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(530, 272)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 20)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Parameter"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(530, 218)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 20)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Area"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblYd)
        Me.Controls.Add(Me.lblDisplayParameterYd)
        Me.Controls.Add(Me.lblAreaDisplayYd)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblFeet)
        Me.Controls.Add(Me.tbLength)
        Me.Controls.Add(Me.tbHeight)
        Me.Controls.Add(Me.lblLength)
        Me.Controls.Add(Me.lblHeight)
        Me.Controls.Add(Me.lblParameterDisplayFeet)
        Me.Controls.Add(Me.lblAreaDisplayFeet)
        Me.Controls.Add(Me.lblParameter)
        Me.Controls.Add(Me.lblArea)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "MainForm"
        Me.Text = "Area Project"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblArea As Label
    Friend WithEvents lblParameter As Label
    Friend WithEvents lblParameterDisplayFeet As Label
    Friend WithEvents lblAreaDisplayFeet As Label
    Friend WithEvents lblLength As Label
    Friend WithEvents lblHeight As Label
    Friend WithEvents tbHeight As TextBox
    Friend WithEvents tbLength As TextBox
    Friend WithEvents lblFeet As Label
    Friend WithEvents lblYd As Label
    Friend WithEvents lblDisplayParameterYd As Label
    Friend WithEvents lblAreaDisplayYd As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
