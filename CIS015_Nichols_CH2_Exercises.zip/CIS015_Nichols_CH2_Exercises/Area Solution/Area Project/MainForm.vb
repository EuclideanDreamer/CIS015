﻿Public Class MainForm
    'Name: Area Project
    'Purpose: Take the length and height of a rectangle in feet and display the area and paraeter in yards and feet

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'variables

        Dim decHeight As Decimal
        Dim decLength As Decimal

        Dim decParameterFeet As Decimal
        Dim decAreaFeet As Decimal

        Dim decParameterYd As Decimal
        Dim decAreaYd As Decimal

        decHeight = tbHeight.Text
        decLength = tbLength.Text

        decAreaFeet = decHeight * decLength

        decParameterFeet = (2 * decHeight) + (2 * decLength)

        decAreaYd = decAreaFeet / 3

        decParameterYd = decParameterFeet / 3

        lblAreaDisplayFeet.Text = decAreaFeet

        lblParameterDisplayFeet.Text = decParameterFeet

        lblAreaDisplayYd.Text = decAreaYd

        lblDisplayParameterYd.Text = decParameterYd



    End Sub
End Class
