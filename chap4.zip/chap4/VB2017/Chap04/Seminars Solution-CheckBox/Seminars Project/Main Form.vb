﻿' Name:         Seminars Project
' Purpose:      Calculate and display the amount due.
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculate and display the amount due.

        Dim intAmountDue As Integer

        ' Determine which (if any) check boxes are selected
        ' and add the associated fee to the amount due.


        lblAmountDue.Text = intAmountDue.ToString("C0")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class
